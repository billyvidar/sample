package com.billyvidar.springboot.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.billyvidar.springboot.model.Employee;

@RestController
public class EmployeeController {


		
	@PostMapping("/employees")
	public ResponseEntity<String> processEmployees(
			@RequestBody Employee employee) {

		if (employee.getRequestId().trim().length()==0 ||
			employee.getEmailAddress().trim().length()==0 ||
			employee.getPeople().size()==0) {

			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
			        .body("\"status\" : \"fail\", details:  ERROR " + HttpStatus.BAD_REQUEST);
		}
		return ResponseEntity.status(HttpStatus.OK)
		        .body("\"status\" : \"ok\", details: processed " + employee.getPeople().size() + " people for "
		        		+ employee.getEmailAddress());
	}
	

}
