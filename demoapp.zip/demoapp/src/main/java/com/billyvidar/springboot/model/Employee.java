package com.billyvidar.springboot.model;

import java.util.HashMap;
import java.util.List;

public class Employee {

	private String requestId;
	private String emailAddress;
	private List<HashMap<String, String>> people;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("***** Employee Details *****\n");
		sb.append("ID="+getRequestId()+"\n");
		sb.append("EmailAddress="+getEmailAddress()+"\n");
		sb.append("People="+getPeople()+"\n");
		sb.append("*****************************");
		
		return sb.toString();
	}

	public List<HashMap<String, String>> getPeople() {
		return people;
	}
	public void setPeople(List<HashMap<String, String>> people) {
		this.people = people;
	}
}
