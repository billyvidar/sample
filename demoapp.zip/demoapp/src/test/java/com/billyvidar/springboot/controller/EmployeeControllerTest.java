package com.billyvidar.springboot.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.billyvidar.springboot.model.Employee;


import org.mockito.InjectMocks;

@RunWith(SpringRunner.class)
public class EmployeeControllerTest {

	@InjectMocks
	    EmployeeController employeeController;

	@Test
	public void processEmployeesTest() throws Exception {

        Employee employee = new Employee();
        employee.setRequestId("");
        employee.setEmailAddress("");
        ArrayList<HashMap<String,String>> people = new ArrayList<HashMap<String, String>>();
        HashMap<String, String> peopleMap = new HashMap<String,String>();
        employee.setPeople(people);
        System.out.println(people.size());
        ResponseEntity<String> responseEntity = employeeController.processEmployees(employee);
        assertEquals(responseEntity.getStatusCodeValue(), 400);
        employee.setRequestId("01-01-01");
        responseEntity = employeeController.processEmployees(employee);
        assertEquals(responseEntity.getStatusCodeValue(), 400);
        employee.setEmailAddress("b.vidar@gmail.com");
        responseEntity = employeeController.processEmployees(employee);
        assertEquals(responseEntity.getStatusCodeValue(), 400);
        people.clear();
        peopleMap.put("name", "Billy");
        peopleMap.put("name", "Lana");
        peopleMap.put("name", "Sophie");
        people.add(peopleMap);
        employee.setPeople(people);
       
        responseEntity = employeeController.processEmployees(employee);
        assertEquals(responseEntity.getStatusCodeValue(), 200);
	}
}
